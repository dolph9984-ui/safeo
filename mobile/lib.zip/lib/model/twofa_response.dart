class TwoFAResponse {
  final String accessToken;
  final String message;

  TwoFAResponse({
    required this.accessToken,
    required this.message,
  });

  factory TwoFAResponse.fromJson(Map<String, dynamic> json) {
    return TwoFAResponse(
      accessToken: json['accessToken'],
      message: json['message'],
    );
  }
}
