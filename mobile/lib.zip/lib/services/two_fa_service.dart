import 'package:dio/dio.dart';
import 'package:securite_mobile/model/twofa_response.dart';
import 'package:securite_mobile/utils/dio_client.dart';

class TwoFAService {
  final Dio _dio = DioClient.dio;

  /// Vérifie le code OTP
  Future<TwoFAResponse> verifyCode({
    required String code,
    required String verificationToken,
  }) async {
    try {
      final response = await _dio.post(
        '/v1/api/auth/login/verify-otp',
        data: {
          'code': code,
          'verificationToken': verificationToken,
        },
      );

      if (response.statusCode == 200) {
        return TwoFAResponse.fromJson(response.data);
      }

      throw Exception('Code invalide');
    } on DioException catch (e) {
      String message = 'Erreur réseau';
      if (e.response != null && e.response!.statusCode == 401) {
        message = 'Code invalide ou expiré';
      } else if (e.response?.data['message'] != null) {
        message = e.response!.data['message'];
      }
      throw Exception(message);
    }
  }

  /// Renvoyer le code OTP
  Future<void> resendCode({required String verificationToken}) async {
    try {
      final response = await _dio.post(
        '/v1/api/auth/login/resend-otp',
        data: {'verificationToken': verificationToken},
      );

      if (response.statusCode != 200) {
        throw Exception('Impossible de renvoyer le code');
      }
    } on DioException catch (e) {
      String message = 'Erreur réseau';
      if (e.response != null && e.response!.statusCode == 401) {
        message = 'Session expirée, veuillez vous reconnecter';
      } else if (e.response?.data['message'] != null) {
        message = e.response!.data['message'];
      }
      throw Exception(message);
    }
  }
}
