class OAuthConstants {
  static final clientID = 'app-safeo';
  static final redirectURI = 'safeo://auth-callback';
}
