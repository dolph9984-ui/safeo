class Routes {
  static final home = '/';
  static final login = '/login';
  static final twoFA = '/2FA';
}