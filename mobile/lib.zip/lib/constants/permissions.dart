class Permissions {
  // pas définitif
  static const admin = [];
  static const superAdmin = [...admin];
}
