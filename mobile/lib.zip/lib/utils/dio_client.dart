import 'package:dio/dio.dart';

class DioClient {
  static final Dio dio = Dio(
    BaseOptions(
      // baseUrl: 'http://10.0.2.2:3000', // ⚠️ Android emulator
      baseUrl: 'http://localhost:3000', // ⚠️ Web / Desktop
      connectTimeout: const Duration(seconds: 10),
      receiveTimeout: const Duration(seconds: 10),
      headers: {
        'Content-Type': 'application/json',
      },
    ),
  );
}
