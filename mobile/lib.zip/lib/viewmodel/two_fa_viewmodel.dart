import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:securite_mobile/services/two_fa_service.dart';
import 'package:securite_mobile/model/twofa_response.dart';

class TwoFAViewModel extends ChangeNotifier {
  final TwoFAService _service = TwoFAService();
  final String verificationToken;

  TwoFAViewModel({required this.verificationToken});

  String _code = '';
  String? _errorMessage;
  bool _isLoading = false;
  int _timerSeconds = 60;
  bool _canResend = false;
  Timer? _timer;

  String get code => _code;
  String? get errorMessage => _errorMessage;
  bool get isLoading => _isLoading;
  int get timerSeconds => _timerSeconds;
  bool get canResend => _canResend;
  bool get canSubmit => _code.length == 6 && !_isLoading;

  void updateCode(String value) {
    if (value.length <= 6) {
      _code = value;
      _clearError();
      notifyListeners();
    }
  }

  void _clearError() {
    if (_errorMessage != null) {
      _errorMessage = null;
      notifyListeners();
    }
  }

  void startTimer() {
    _canResend = false;
    _timerSeconds = 60;
    notifyListeners();

    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_timerSeconds > 0) {
        _timerSeconds--;
        notifyListeners();
      } else {
        _canResend = true;
        timer.cancel();
        notifyListeners();
      }
    });
  }

  /// Vérifie le code OTP
  Future<TwoFAResponse?> submit() async {
    if (!canSubmit) return null;

    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      final response = await _service.verifyCode(
        code: _code,
        verificationToken: verificationToken,
      );

      _isLoading = false;
      notifyListeners();

      return response;
    } catch (e) {
      _errorMessage = e.toString().replaceFirst('Exception: ', '');
      _isLoading = false;
      notifyListeners();
      return null;
    }
  }

  /// Renvoyer le code OTP
  Future<void> resend() async {
    if (!_canResend || _isLoading) return;

    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      await _service.resendCode(verificationToken: verificationToken);
      _isLoading = false;
      startTimer();
      notifyListeners();
    } catch (e) {
      _errorMessage = e.toString().replaceFirst('Exception: ', '');
      _isLoading = false;
      notifyListeners();
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }
}
