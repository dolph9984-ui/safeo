import 'package:flutter/foundation.dart';

class TwoFAViewModel extends ChangeNotifier {}
