import 'package:flutter/material.dart';

class TwoFAView extends StatelessWidget {
  const TwoFAView({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
